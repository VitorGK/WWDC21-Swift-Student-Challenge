/*:
 Hey! Here is a little more about me:
 ___
 
 ![A picture of me](me.jpg "VitorGK" width="250" height="250")
 
 # My name is...
 
 Vitor Grechi Kuninari, I'm a brazilian guy who likes to play videogames, code and make music.
 
 I was born on March 1st, 2001
 
 I spend the morning studying, the afternoon at Apple Developer Academy | Mackenzie and the evening relaxing a bit.
 ___
 
 What really inspired me to do a pinball machine for Swift Playgrounds was a video I watched months ago from a YouTube channel named The Slow Mo Guys.
 
 I always wanted to play on a real machine, although I never had the opportunity.
 ___
 
 Besides games, I really like music, mainly electronic music... And japanese food... And Rubik's cubes... Eh, a lot of things.
 
 ___
 
 With this Playground, I want people to feel the same I feel when I play, listen or do anything they like.
 
 I want them to feel **happy** and have fun!   :D
 ___
 
 My code stuff: [GitHub](https://github.com/vitorgk)
 
 My music stuff: [SoundCloud](https://soundcloud.com/vitorgk)
 
 */
//#-code-completion(everything, hide)
